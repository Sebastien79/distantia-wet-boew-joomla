-- phpMyAdmin SQL Dump
-- version 4.0.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 15, 2014 at 05:09 PM
-- Server version: 5.5.35-0ubuntu1-log
-- PHP Version: 5.5.8-2ubuntu1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fpcc_cpac`
--

-- --------------------------------------------------------

--
-- Table structure for table `vwqtd_modules`
--

CREATE TABLE IF NOT EXISTS `vwqtd_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10098 ;

--
-- Dumping data for table `vwqtd_modules`
--

INSERT INTO `vwqtd_modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 'MENU RAPIDE', '', '', 1, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"menurapidefrancais","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"cpac-vmenu","window_open":"","layout":"_:default","moduleclass_sfx":"cpac-vmenu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'fr-FR'),
(2, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(8, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(79, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(86, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(10001, 'Menu principal', '', '', 0, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_mainmenu', 1, 0, '{"menutype":"mainmenu","menu_style":"vert_indent","startLevel":"0","endLevel":"0","showAllChildren":"1","window_open":"","show_whitespace":"0","cache":"0","tag_id":"","class_sfx":"cpac-vmenu","moduleclass_sfx":"cpac-vmenu","maxdepth":"25","menu_images":"1","menu_images_align":"0","menu_images_link":"1","expand_menu":"0","activate_parent":"0","full_active_id":"0","indent_image":"3","indent_image1":"arrow.png","indent_image2":"","indent_image3":"","indent_image4":"","indent_image5":"","indent_image6":"","spacer":"....","end_spacer":"...."}', 0, ''),
(10016, 'Images aléatoires', '', '', 4, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_random_image', 1, 0, '{"type":"jpg","folder":"images\\/entetes","link":"","width":"752","height":"139","moduleclass_sfx":"","cache":"0","cache_time":"900"}', 0, ''),
(17, 'Menu top', '', '', 7, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_mainmenu', 1, 0, '{"menutype":"topmenu","menu_style":"list_flat","startLevel":"0","endLevel":"0","showAllChildren":"0","window_open":"","show_whitespace":"0","cache":"1","tag_id":"","class_sfx":"cpac-hmenu","moduleclass_sfx":"","maxdepth":"10","menu_images":"1","menu_images_align":"0","menu_images_link":"0","expand_menu":"0","activate_parent":"0","full_active_id":"0","indent_image":"0","indent_image1":"-1","indent_image2":"","indent_image3":"","indent_image4":"","indent_image5":"","indent_image6":"","spacer":"","end_spacer":""}', 0, ''),
(10035, 'NOUVEAUTÉS', '', '', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_latestnews', 1, 1, '{"count":"5","ordering":"c_dsc","user_id":"0","show_front":"0","secid":"","catid":"","moduleclass_sfx":"","cache":"1","cache_time":"900"}', 0, ''),
(10024, 'Bas de page', '', '<table border="0" cellspacing="0" cellpadding="5" width="100%">\r\n<tbody>\r\n<tr valign="top">\r\n<td>&nbsp;</td>\r\n<td><a href="#up">Haut de page </a></td>\r\n<td width="20%" align="center">\r\n<div><a href="index.php/fra/avis-importants">Avis importants</a></div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p> </p>', 0, 'copyright', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"moduleclass_sfx":""}', 0, ''),
(10042, 'Plan prospectif de la réglementation : 2012-2014', '', '<p><strong>Plan prospectif de la réglementation&nbsp;:&nbsp;2012-2014 </strong><strong>&nbsp;</strong></p>\r\n<p>Le présent plan fournit des renseignements sur les propositions de réglementation que l’Agence du revenu du Canada compte présenter au cours des deux prochaines années. Il décrit également les possibilités de consultation publique et contient des informations sur la personne-ressource du ministère pour chacune des initiatives de réglementation.</p>\r\n<p><strong>Initiatives de réglementation proposées </strong></p>', 0, 'user2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"moduleclass_sfx":""}', 0, ''),
(10027, 'Fil', '', '', 1, 'breadcrumb', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 0, '{"showHere":"0","showHome":"1","homeText":"Accueil","showLast":"1","separator":">","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, 'fr-FR'),
(10028, 'Menu vertical', '', '', 3, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_mainmenu', 1, 0, '{"menutype":"menu-vertical","menu_style":"vert_indent","startLevel":"0","endLevel":"0","showAllChildren":"1","window_open":"","show_whitespace":"0","cache":"1","tag_id":"","class_sfx":"","moduleclass_sfx":"","maxdepth":"10","menu_images":"1","menu_images_align":"0","menu_images_link":"1","expand_menu":"0","activate_parent":"1","full_active_id":"1","indent_image":"0","indent_image1":"","indent_image2":"","indent_image3":"","indent_image4":"","indent_image5":"","indent_image6":"","spacer":"","end_spacer":""}', 0, ''),
(10041, 'SONDAGE', '', '', 0, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_poll', 1, 1, '{"id":"15","moduleclass_sfx":"-poll","cache":"1","cache_time":"900"}', 0, ''),
(10037, 'BULLETIN FOCUS', '', '<section>\r\n	<h2 class="ac-hp-bg margin-bottom-none margin-top-medium">Bulletin Focus</h2>\r\n	<p class="background-light margin-top-none" style="padding-bottom: 20px;"><img src="images/FOCUSSEPTEMBRE2013.jpg" alt="FOCUSSEPTEMBRE2013" /><br /><a style="margin-left: 10px;" href="images/PDF/FOCUS_Fre_Novembre_2013_FINAL.pdf">Focus Nov. 2013</a><br /><a style="margin-left: 10px;" href="index.php?option=com_content&amp;view=article&amp;id=40&amp;Itemid=128">Pour vous inscrire</a>\r\n	</p>\r\n</section>', 2, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'fr-FR'),
(10038, 'INTRANET', '', '', 4, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_mainmenu', 1, 1, '{"menutype":"intranet","menu_style":"vert_indent","startLevel":"0","endLevel":"0","showAllChildren":"1","window_open":"","show_whitespace":"1","cache":"1","tag_id":"","class_sfx":"cpac-vmenu","moduleclass_sfx":"cpac-vmenu","maxdepth":"10","menu_images":"1","menu_images_align":"0","menu_images_link":"1","expand_menu":"0","activate_parent":"0","full_active_id":"1","indent_image":"3","indent_image1":"","indent_image2":"","indent_image3":"","indent_image4":"","indent_image5":"","indent_image6":"","spacer":"","end_spacer":""}', 0, ''),
(10040, 'CALENDRIER', '', '', 3, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_artcalendar', 1, 1, '{"moduleclass_sfx":"","show":"calendar","calendar":"1","calendarGroup":"1","noConflict":"0","defaultMonth":"0","calendarType":"1","gCalWidth":"195","gCalHeight":"195"}', 0, ''),
(10043, 'Plus d''info', '', '<p><strong>Pour plus d''information</strong></p>\r\n<ul class="s">\r\n<li><a href="http://www.tbs-sct.gc.ca/tbs-sct/ar-lr/gwfrp-ppreg-fra.asp" target="_blank">Plans prospectifs de la réglementation à l''échelle&nbsp;<br />du gouvernement</a></li>\r\n<li><a href="http://www.tbs-sct.gc.ca/rtrap-parfa/cdrm-dcgr/cdrm-dcgrtb-fra.asp" target="_blank">Directive du Cabinet sur la gestion de la réglementation</a></li>\r\n<li><a href="http://actionplan.gc.ca/fr/initiative/reduire-les-tracasseries-administratives" target="_blank">Réduire les tracasseries administratives</a></li>\r\n<li><a href="http://actionplan.gc.ca/fr/page/rcc-ccr/plan-daction-conjoint-du-conseil-de-cooperation" target="_blank">Plan d''action conjoint du Conseil de coopération en matière de réglementation</a></li>\r\n</ul>\r\n<p class="sd"> </p>\r\n<p class="sd">Pour en apprendre plus sur la venue ou la tenue de consultations concernant les lois fédérales proposées, visitez&nbsp;<a href="http://www.gazette.gc.ca/index-fra.html" target="_blank">La Gazette du Canada</a> et le site Web de&nbsp;<a href="http://www.consultation-des-canadiens.gc.ca/hm.jspx?lang=fra" target="_blank">Consultations auprès des Canadiens</a>.</p>', 0, 'user5', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"moduleclass_sfx":""}', 0, ''),
(10048, 'Menu principal', '', '', 1, 'boew-menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"topmenufrancais","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'fr-FR'),
(10045, 'Français', '', '', 2, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_languages', 1, 0, '{"header_text":"","footer_text":"","dropdown":"0","image":"1","inline":"1","show_active":"1","full_name":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'fr-FR'),
(10046, 'English', '', '', 3, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_languages', 1, 1, '{"header_text":"","footer_text":"","dropdown":"0","image":"1","inline":"1","show_active":"1","full_name":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB'),
(10050, 'Photos nouvelles accueil', '', '', 8, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_twojtoolbox', 1, 0, '{"type":"newsslider","id":"2","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"static","twojInclude":"0"}', 0, 'fr-FR'),
(10060, 'Bas', '', '<ul style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: #040707;">\r\n<li style="margin: 12px 35px 13px 9px; float: left;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://canadiensensante.gc.ca/index-fra.php" rel="external"><span style="text-transform: uppercase; font-weight: bold;">SANTÉ</span><br />canadiensensante.gc.ca</a></li>\r\n<li style="margin: 12px 35px 13px 9px; float: left;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://www.voyage.gc.ca/index-fra.asp" rel="external"><span style="text-transform: uppercase; font-weight: bold;">VOYAGE</span><br />voyage.gc.ca</a></li>\r\n<li style="margin: 12px 35px 13px 9px; float: left;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://www.servicecanada.gc.ca/fra/accueil.shtml" rel="external"><span style="text-transform: uppercase; font-weight: bold;">SERVICE CANADA</span><br />servicecanada.gc.ca</a></li>\r\n<li style="margin: 12px 35px 13px 9px; float: left;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://www.guichetemplois.gc.ca/Intro-fra.aspx" rel="external"><span style="text-transform: uppercase; font-weight: bold;">EMPLOIS</span><br />guichetemplois.gc.ca</a></li>\r\n<li style="margin: 12px 35px 13px 9px; float: left;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://plandaction.gc.ca/fr" rel="external"><span style="text-transform: uppercase; font-weight: bold;">ÉCONOMIE</span><br />plandaction.gc.ca</a></li>\r\n<li id="cn-ft-ca" style="margin: 12px 5px 13px 9px; float: right;">\r\n<div style="font-size: 22px; text-align: right; margin: 0px;"><a style="color: #ffffff; font-size: 0.95em; display: inline-block; border-left-width: 1px; border-left-style: solid; border-left-color: #666666; line-height: 1.45em; padding-left: 44px; padding-right: 10px;" href="http://www.canada.gc.ca/accueil.html">Canada.gc.ca</a></div>\r\n</li>\r\n</ul>', 2, 'extra1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"images\\/fonnoir.jpg","layout":"_:default","moduleclass_sfx":"centre","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(10061, 'Bas de page avec feuille', '', '<!-- Footer begins / Début du pied de page -->\r\n<div id="gcwu-tctr">\r\n	<ul>\r\n		<li class="gcwu-tc"><a href="index.php?option=com_content&amp;view=article&amp;id=155&amp;Itemid=238" rel="license">Avis</a>\r\n		</li>\r\n		<li class="gcwu-tr"><a href="index.php/fr-FR/cpac/rapports/divulgations-proactive">Transparence</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="index.php?option=com_content&amp;view=article&amp;id=15&amp;Itemid=292">À propos de nous</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="index.php?option=com_content&amp;view=article&amp;id=60&amp;Itemid=212">Plan du site</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="index.php?option=com_content&amp;view=featured&amp;Itemid=187">Nouvelles</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="index.php?option=com_content&amp;view=article&amp;id=18&amp;Itemid=295">Communiqués</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="index.php?option=com_content&amp;view=article&amp;id=40&amp;Itemid=128">Contactez-nous</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="http://www.canada.gc.ca/directories-repertoires/direct-fra.html">Joindre votre gouvernement</a>\r\n		</li>\r\n		<li><a href="http://www.canada.gc.ca/directories-repertoires/direct-fra.html#dep">Joindre votre député de la Chambre des communes</a>\r\n		</li>\r\n		<li><a href="http://www.canada.gc.ca/comments-commentaires/think-pensez-fra.html">Qu''en pensez-vous?</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="http://www.canada.gc.ca/socialmedia-mediasociaux/media-fra.html">Restez branchés</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="http://nouvelles.gc.ca/web/distributions-fra.do" rel="external">Fils de nouvelle</a>\r\n		</li>\r\n		<li><a href="http://www.canada.gc.ca/mobile/wireless-fra.html">Portail mobile</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<!-- <div id="cn-foot">\r\n	<div id="cn-foot-inner">\r\n		<table style="height: 180px; width: 850px;" border="0" cellspacing="0" cellpadding="0" align="center">\r\n			<tbody>\r\n				<tr valign="top">\r\n					<td><br /><br /><br />\r\n						<ul style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: #efefef;">\r\n							<li class="terms" style="display: inline; border-right-width: 1px; border-right-style: solid; border-right-color: #999999; padding-right: 9px; padding-left: 10px;"><a style="color: #222222; text-decoration: none; line-height: 1.75em;" href="index.php?option=com_content&amp;view=article&amp;id=155&amp;Itemid=238" rel="license">Avis</a>\r\n							</li>&nbsp;\r\n							<li class="trans" style="display: inline; padding-left: 6px;"><a class="gl-outbound" style="color: #222222; text-decoration: none; line-height: 1.75em;" href="http://fpcc-cpac.gc.ca/index.php/fr-FR/cpac/rapports/divulgations-proactive" rel="external">Transparence</a>\r\n							</li>\r\n						</ul>\r\n						<p><span style="color: #000000;"><span style="color: #000000;">&nbsp;</span></span>\r\n						</p>\r\n						<h4 class="col-head" style="margin-top: 10px; margin-bottom: 5px; font-size: 14px; vertical-align: bottom; border: none; font-family: Arial, Helvetica, sans-serif; background-color: #efefef;"><a style="color: #222222; text-decoration: none;" href="index.php?option=com_content&amp;view=article&amp;id=15&amp;Itemid=292">À propos de nous</a>\r\n						</h4>\r\n						<ul style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: #efefef;">\r\n							<li><a style="color: #222222; text-decoration: none; line-height: 1.75em;" href="index.php?option=com_content&amp;view=article&amp;id=60&amp;Itemid=212">Plan du site</a>\r\n							</li>\r\n						</ul>\r\n					</td>\r\n					<td>\r\n						<p class="col-head" style="font-size: 11px;"><span style="color: #000000;">&nbsp;</span>\r\n						</p>\r\n						<p><span style="color: #000000;">&nbsp;</span>\r\n						</p>\r\n						<p class="col-head" style="font-size: 11px;"><span style="color: #000000;">&nbsp;</span>\r\n						</p><br />\r\n						<p class="col-head" style="font-size: 11px;"><span style="color: #000000;">&nbsp;<br /><br /></span>\r\n						</p>\r\n						<h4 class="col-head" style="margin-top: 10px; margin-bottom: 5px; font-size: 14px; vertical-align: bottom; border: none; font-family: Arial, Helvetica, sans-serif; background-color: #efefef;"><a class="gl-outbound" style="color: #222222; text-decoration: none;" href="index.php?option=com_content&amp;view=featured&amp;Itemid=187" rel="external">Nouvelles</a>\r\n						</h4>\r\n						<ul style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: #efefef;">\r\n							<li><a class="gl-outbound" style="color: #222222; text-decoration: none; line-height: 1.75em;" href="index.php?option=com_content&amp;view=article&amp;id=18&amp;Itemid=295" rel="external">Communiqués</a>\r\n							</li>\r\n						</ul>\r\n					</td>\r\n					<td>\r\n						<p class="col-head" style="font-size: 11px;"><span style="color: #000000;"><img src="images/feuilllle.jpg" alt="Feuille Canada" /></span>\r\n						</p>\r\n						<p class="col-head" style="font-size: 11px;"><span style="color: #000000;">&nbsp;</span>\r\n						</p>\r\n						<h4 class="col-head" style="margin-top: 10px; margin-bottom: 5px; font-size: 14px; vertical-align: bottom; border: none; font-family: Arial, Helvetica, sans-serif; background-color: #efefef;"><a style="color: #222222; text-decoration: none;" href="index.php?option=com_content&amp;view=article&amp;id=40&amp;Itemid=128">Contactez-nous</a>\r\n						</h4>\r\n						<ul>\r\n							<li><a style="color: #222222; text-decoration: none; line-height: 1.75em;" href="http://www.canada.gc.ca/directories-repertoires/direct-fra.html">Joindre votre gouvernement</a>\r\n							</li>\r\n							<li><a style="color: #222222; text-decoration: none; line-height: 1.75em;" href="http://www.canada.gc.ca/directories-repertoires/direct-fra.html#dep">Joindre votre député de la Chambre des communes</a>\r\n							</li>\r\n							<li><a style="color: #222222; text-decoration: none; line-height: 1.75em;" href="http://www.canada.gc.ca/comments-commentaires/think-pensez-fra.html">Qu''en pensez-vous?</a>\r\n							</li>\r\n						</ul>\r\n					</td>\r\n					<td><br /><br /><br /><br /><br />\r\n						<h4 class="col-head" style="margin-top: 10px; margin-bottom: 5px; font-size: 14px; vertical-align: bottom; border: none; font-family: Arial, Helvetica, sans-serif; background-color: #efefef;"><a style="color: #222222; text-decoration: none;" href="http://www.canada.gc.ca/socialmedia-mediasociaux/media-fra.html">Restez branchés</a>\r\n						</h4>\r\n						<ul style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: #efefef;">\r\n							<li><a class="gl-outbound" style="color: #222222; text-decoration: none; line-height: 1.75em;" href="http://nouvelles.gc.ca/web/distributions-fra.do" rel="external">Fils de nouvelle</a>\r\n							</li>\r\n							<li><a style="color: #222222; text-decoration: none; line-height: 1.75em;" href="http://www.canada.gc.ca/mobile/wireless-fra.html">Portail mobile</a>\r\n							</li>\r\n						</ul>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table><br /><br />\r\n		<table style="width: 1020px; height: 51px;" border="0" align="center">\r\n			<tbody>\r\n				<tr>\r\n					<td style="text-align: center;">\r\n						<ul style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; background-color: #040707;">\r\n							<li style="margin: 12px 35px 13px 9px; float: left;"><span style="font-family: arial, helvetica, sans-serif;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://canadiensensante.gc.ca/index-fra.php" rel="external"><span style="text-transform: uppercase; font-weight: bold;">SANTÉ</span><br />canadiensensante.gc.ca</a> </span>\r\n							</li>\r\n							<li style="margin: 12px 35px 13px 9px; float: left;"><span style="font-family: arial, helvetica, sans-serif;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://www.voyage.gc.ca/index-fra.asp" rel="external"><span style="text-transform: uppercase; font-weight: bold;">VOYAGE</span><br />voyage.gc.ca</a> </span>\r\n							</li>\r\n							<li style="margin: 12px 35px 13px 9px; float: left;"><span style="font-family: arial, helvetica, sans-serif;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://www.servicecanada.gc.ca/fra/accueil.shtml" rel="external"><span style="text-transform: uppercase; font-weight: bold;">SERVICE CANADA</span><br />servicecanada.gc.ca</a> </span>\r\n							</li>\r\n							<li style="margin: 12px 35px 13px 9px; float: left;"><span style="font-family: arial, helvetica, sans-serif;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://www.guichetemplois.gc.ca/Intro-fra.aspx" rel="external"><span style="text-transform: uppercase; font-weight: bold;">EMPLOIS</span><br />guichetemplois.gc.ca</a> </span>\r\n							</li>\r\n							<li style="margin: 12px 35px 13px 9px; float: left;"><span style="font-family: arial, helvetica, sans-serif;"><a class="gl-outbound" style="color: #ffffff; text-decoration: none; font-size: 12px;" href="http://plandaction.gc.ca/fr" rel="external"><span style="text-transform: uppercase; font-weight: bold;">ÉCONOMIE</span><br />plandaction.gc.ca</a> </span>\r\n							</li>\r\n							<li id="cn-ft-ca" style="margin: 12px 5px 13px 9px; float: right;">\r\n								<div style="font-size: 22px; text-align: right; margin: 0px;"><span style="font-family: arial, helvetica, sans-serif;"><a style="color: #ffffff; text-decoration: none; font-size: 0.95em; display: inline-block; border-left-width: 1px; border-left-style: solid; border-left-color: #666666; line-height: 1.45em; padding-left: 20px; padding-right: 10px;" href="http://www.canada.gc.ca/accueil.html">Canada.gc.ca</a></span>\r\n								</div>\r\n							</li>\r\n						</ul>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n	</div>\r\n</div>\r\n-->\r\n<p>&nbsp;</p>', 1, 'debug', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"images\\/basdepage.jpg","layout":"_:default","moduleclass_sfx":"center","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'fr-FR'),
(10072, 'Menu principal anglais', '', '', 2, 'boew-menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"menuhautanglais","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB'),
(10073, 'Bannierehaut anglaise', '', '<ul>\r\n	<li id="gcwu-gcnb1"><a href="http://www.canada.gc.ca/menu-fra.html" rel="external">Canada.gc.ca</a></li>\r\n	<li id="gcwu-gcnb2"><a href="http://www.servicecanada.gc.ca/eng/home.shtml" rel="external">Services</a></li>\r\n	<li id="gcwu-gcnb3"><a href="http://www.canada.gc.ca/depts/major/depind-eng.html" rel="external">Department</a>{module Langues}</li>\r\n</ul>', 1, 'top', 342, '2014-02-10 21:07:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'en-GB'),
(10062, 'Conseil des produits agricoles du Canada', '', '<a href="index.php?option=com_content&amp;view=featured&amp;Itemid=127">Conseil des produits agricoles<br />du Canada</a>', 1, 'header', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'fr-FR'),
(10063, 'EN VEDETTE', '', '<p><a href="index.php?option=com_content&amp;view=category&amp;id=24&amp;Itemid=207"><img style="display: block; margin-left: auto; margin-right: auto;" src="images/focus.jpg" alt="focus" /></a></p>', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 1, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'fr-FR'),
(10064, 'À SURVEILLER', '', '', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_articles_news', 1, 1, '{"catid":["8"],"image":"0","item_title":"1","link_titles":"1","item_heading":"h4","showLastSeparator":"1","readmore":"0","count":"5","ordering":"a.publish_up","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(10065, 'À SURVEILLER', '', '', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_articles_category', 1, 1, '{"mode":"dynamic","show_on_article_page":"1","show_front":"show","count":"5","category_filtering_type":"1","catid":["8"],"show_child_category_articles":"0","levels":"1","author_filtering_type":"1","created_by":[""],"author_alias_filtering_type":"1","created_by_alias":[""],"excluded_articles":"","date_filtering":"off","date_field":"a.created","start_date_range":"","end_date_range":"","relative_date":"30","article_ordering":"a.title","article_ordering_direction":"ASC","article_grouping":"none","article_grouping_direction":"ksort","month_year_format":"F Y","item_heading":"5","link_titles":"1","show_date":"0","show_date_field":"created","show_date_format":"Y-m-d H:i:s","show_category":"0","show_hits":"0","show_author":"0","show_introtext":"0","introtext_limit":"100","show_readmore":"0","show_readmore_title":"1","readmore_limit":"15","layout":"_:default","moduleclass_sfx":"","owncache":"1","cache_time":"900"}', 0, '*'),
(10066, 'À SURVEILLER', '', '', 1, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_articles_category', 1, 1, '{"mode":"normal","show_on_article_page":"1","show_front":"show","count":"1","category_filtering_type":"1","catid":["49"],"show_child_category_articles":"0","levels":"1","author_filtering_type":"1","created_by":[""],"author_alias_filtering_type":"1","created_by_alias":[""],"excluded_articles":"","date_filtering":"off","date_field":"a.created","start_date_range":"","end_date_range":"","relative_date":"30","article_ordering":"a.title","article_ordering_direction":"ASC","article_grouping":"none","article_grouping_direction":"ksort","month_year_format":"F Y","item_heading":"5","link_titles":"0","show_date":"0","show_date_field":"created","show_date_format":"Y-m-d H:i:s","show_category":"0","show_hits":"0","show_author":"0","show_introtext":"1","introtext_limit":"0","show_readmore":"0","show_readmore_title":"0","readmore_limit":"0","layout":"_:default","moduleclass_sfx":"cpac-vmenu","owncache":"1","cache_time":"900"}', 0, '*'),
(10067, 'À SURVEILLER', '', '\r\n\r\n		<h2 class="ac-hp-bg margin-bottom-none margin-top-medium">À surveiller</h2>\r\n		<ul>\r\n			<li>Rapport Annuel du CPAC 2012-2013 (<a href="images/PDF/CPAC%202012-2013%20Rapport%20Annuel.pdf">PDF</a>)</li>\r\n			<li>Le ministre Ritz annonce une nomination au Conseil des produits agricoles du Canada&nbsp;(<a href="images/Communique2013.pdf" target="_blank">PDF</a>)</li>\r\n			<li>Nouveau membre au CPAC - Communiqué (<a href="http://www.fpcc-cpac.gc.ca/images/PDF/communiqu%20john%20griffin%20juin%202012.pdf">PDF</a>)</li>\r\n			<li><a href="http://fpcc-cpac.gc.ca/index.php/fr-FR/cpac/publications/78-fpcc-cpac/le-cpac/publications/543-allocutions-fr-fr-1">Notes d''allocutions</a>&nbsp;des agences nationales 2013</li>\r\n			<li><a href="index.php?option=com_content&amp;view=article&amp;id=756:rapport-de-verification-des-controles-de-base-fr-fr-1&amp;catid=78:publications">Vérification des contrôles de base en place au CPAC&nbsp;</a>(<a href="images/PDF/cpac%20verification%20des%20controles%20final.pdf">PDF</a>)\r\n				<p class="background-light margin-top-none">Pour une copie du&nbsp;Plan d''action veuillez&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;id=527&amp;Itemid=128">nous contacter</a>.&nbsp;</p>\r\n			</li>\r\n			<li><a href="index.php?option=com_content&amp;view=article&amp;id=738:lignes-directrices-provisoires-pour-le-traitement-des-plaintes-fr-fr-1&amp;catid=78:publications">Lignes directrices provisoires pour le traitement des plaintes&nbsp;</a>(<a href="images/PDF/2011-03-09%20-%20complaints%20guidelines_fr.pdf">PDF</a>)</li>\r\n			<li><a href="index.php?option=com_content&amp;view=article&amp;id=780:plan-strategique-2012-2015-fr-fr-1&amp;catid=77:rapports">Plan Stratégique du CPAC pour 2012-2015&nbsp;</a>(<a href="images/PDF/fpcc_strategicplan_french_2012-2015.pdf">PDF</a>)\r\n				<p class="background-light margin-top-none">Pour une copie des documents ci-haut mentionNés veuillez&nbsp;<a href="index.php?option=com_content&amp;view=article&amp;id=527&amp;Itemid=128">nous contacter</a>.&nbsp;</p>\r\n			</li>\r\n		</ul>\r\n		<div class="clear">&nbsp;</div>\r\n', 1, 'bottom1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'fr-FR'),
(10068, 'INTRANET', '', '', 1, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"intranetfrancais","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"cpac-vmenu","layout":"_:default","moduleclass_sfx":"cpac-vmenu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'fr-FR'),
(10069, 'Recherche', '', '', 1, 'extra2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_search', 1, 0, '{"label":"","width":"30","text":"","button":"1","button_pos":"right","imagebutton":"","button_text":"Recherche","opensearch":"1","opensearch_title":"","set_itemid":"","layout":"_:default","moduleclass_sfx":"cpac-search","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(10070, 'Bannierehaut', '', '<ul>\r\n	<li id="gcwu-gcnb1"><a href="http://www.canada.gc.ca/menu-fra.html" rel="external">Canada.gc.ca</a></li>\r\n	<li id="gcwu-gcnb2"><a href="http://www.servicecanada.gc.ca/fra/accueil.shtml" rel="external">Services</a></li>\r\n  <li id="gcwu-gcnb3"><a href="http://www.canada.gc.ca/depts/major/depind-fra.html" rel="external">Ministères</a>{module Langues}</li>\r\n</ul>', 1, 'top', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'fr-FR'),
(10091, 'Langues (copie)', '', '', 1, 'top', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_languages', 1, 0, '{"header_text":"","footer_text":"","dropdown":"0","image":"0","inline":"1","show_active":"0","full_name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(10090, 'Josetta', 'Ne changez pas le nom de ce module!!!', '', 0, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_menu', 4, 1, '{"menutype":"josetta"}', 0, '*'),
(10081, 'Photos nouvelles accueil anglaises', '', '', 9, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_twojtoolbox', 1, 0, '{"type":"newsslider","id":"2","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"static","twojInclude":"0"}', 0, 'en-GB'),
(10074, 'Langues', '', '', 2, 'top3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_languages', 1, 0, '{"header_text":"","footer_text":"","dropdown":"0","image":"0","inline":"1","show_active":"0","full_name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(10075, 'Conseil des produits agricoles du Canada anglais', '', '<a href="index.php?option=com_content&amp;view=featured&amp;Itemid=127">Farm Products Council of Canada</a>\r\n', 1, 'header', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'en-GB'),
(10076, 'LATEST NEWS', '', '<h2 class="ac-hp-bg margin-bottom-none margin-top-medium">Latest News</h2>\r\n<ul>\r\n	<li>FPCC 2012-2013 Annual Report (<a href="images/PDF/FPCC%202012-2013%20Annual%20Report.pdf">PDF</a>)</li>\r\n	<li>Minister Ritz Announces Appointment to the Farm Products Council of Canada(<a href="images/NewsRelease2013.pdf" target="_blank">PDF</a>)</li>\r\n	<li>New Council member at FPCC - News Release (<a href="http://www.fpcc-cpac.gc.ca/images/PDF/communiqu%20john%20griffin%20juin%202012.pdf">PDF</a>)</li>\r\n	<li>National Marketing Agencies 2013 AGM&nbsp;<a href="http://fpcc-cpac.gc.ca/index.php/en-GB/the-fpcc/publications/2-uncategorised/1364-speeches">Speeches</a></li>\r\n	<li><a href="index.php?option=com_content&amp;view=article&amp;id=757:infosourceeng&amp;catid=2:uncategorised">Core Control Audit of the FPCC </a>(<a href="http://www.fpcc-cpac.gc.ca/images/PDF/fpcc%20audit%20report%20final.pdf">PDF</a>)\r\n		<p class="background-light margin-top-none">For a copy of the Management&nbsp;action plan please&nbsp;<a href="index.php?option=com_content&view=article&id=528&Itemid=311&lang=en-GB">contact us</a>\r\n		</p></li>\r\n	<li><a href="index.php?option=com_content&amp;view=article&amp;id=739:interim-complaint-guidelines&amp;catid=2:uncategorised">Interim Complaint Guidelines</a>&nbsp;(<a href="http://www.fpcc-cpac.gc.ca/images/PDF/2011-03-09%20-%20complaints%20guidelines_en.pdf">PDF</a>)&nbsp;</li>\r\n	<li><a href="index.php?option=com_content&amp;view=article&amp;id=781:strategic-plan-2012-2015&amp;catid=2:uncategorised">Strategic Plan 2012-2015&nbsp;</a>(<a href="http://www.fpcc-cpac.gc.ca/images/PDF/fpcc_strategicplan_eng_2012-2015.pdf">PDF</a>)</li>\r\n</ul>\r\n<div class="clear">&nbsp;</div>', 1, 'bottom1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'en-GB'),
(10077, 'FOCUS BULLETIN', '', '<h2 class="ac-hp-bg margin-bottom-none margin-top-medium">Focus Bulletin</h2>\r\n<p class="background-light margin-top-none" style="padding-bottom: 20px;"><img src="images/FOCUSSEPTEMBRE2013.jpg" alt="FOCUSSEPTEMBRE2013" /><br /><a style="margin-left: 10px;" href="images/PDF/FOCUS_Eng_November_2013_FINAL.pdf">Focus Nov. 2013</a><br /><a style="margin-left: 10px;" href="index.php?option=com_content&amp;view=article&amp;id=528&amp;Itemid=311">Subscribe</a>\r\n</p>', 2, 'right', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'en-GB'),
(10078, 'Bas de page avec feuiille anglais', '', '<!-- Footer begins / Début du pied de page -->\r\n<div id="gcwu-tctr">\r\n	<ul>\r\n		<li class="gcwu-tc"><a href="index.php/en-GB/important-noticesetc" rel="license">Terms and conditions</a>\r\n		</li>\r\n		<li class="gcwu-tr"><a href="index.php/en-GB/the-fpcc/reports/proactive-disclosures">Transparency</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="clear">&nbsp;</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="index.php/en-GB/the-fpcc/history">About us</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="index.php/en-GB/glossaryetc">Site map</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="index.php?option=com_content&amp;view=featured&amp;Itemid=187">News</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="index.php?option=com_content&amp;view=article&amp;id=1119:news-releases&amp;catid=104:josetta-categorie-creee-automatiquement-1-en-gb">News releases</a>\r\n		</li>\r\n	</ul>\r\n</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="index.php/en-GB/contact-us">Contact Us</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="http://www.canada.gc.ca/directories-repertoires/direct-eng.html">Contact your government</a>\r\n		</li>\r\n		<li><a href="http://www.canada.gc.ca/directories-repertoires/direct-eng.html#mem">Contact your Member of Parliament</a>\r\n		</li>\r\n		<!-- <li><a href="http://www.canada.gc.ca/comments-commentaires/think-pensez-fra.html">Qu''en pensez-vous?</a>\r\n		</li>\r\n		-->\r\n	</ul>\r\n</div>\r\n<div class="span-2">\r\n	<h4 class="gcwu-col-head"><a href="http://www.canada.gc.ca/socialmedia-mediasociaux/media-eng.html">Stay connected</a>\r\n	</h4>\r\n	<ul>\r\n		<li><a href="http://news.gc.ca/web/distributions-eng.do" rel="external">Feeds</a>\r\n		</li>\r\n		<li><a href="http://www.canada.gc.ca/mobile/wireless-eng.html">Mobile Portal</a>\r\n		</li>\r\n	</ul>\r\n</div>', 1, 'debug', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"images\\/basdepage.jpg","layout":"_:default","moduleclass_sfx":"center","cache":"1","cache_time":"900","cachemode":"static"}', 0, 'en-GB'),
(10094, 'Wet-Slider', '', '<div class="tabs-panel">\r\n	<!-- TAB START -->\r\n	<div id="tab01">\r\n		<h3 class="align-left span-3 position-right margin-top-none margin-bottom-none">Le CPAC lance son nouveau site Web!</h3>\r\n		<div class="span-3 row-end margin-bottom-none float-right">\r\n			<p class="margin-right-medium margin-top-xlarge-custom">Le conseil des produits agricoles du Canada est fier de lancer son tout nouveau site Web! Vous pourrez maintenant y naviguer à partir de votre téléphone intelligent ou votre tablette et profiter de plusieurs nouvelles fonctionnalités dans un nouvel environnement, pour mieux vous servir.</p>\r\n			<!-- <p class="margin-right-medium margin-top-large">\r\n  <a href="http://nouvelles.gc.ca/web/article-fr.do?mthd=tp&amp;crtr.page=1&amp;nid=814209&amp;crtr.tp1D=1" class="button button-accent">Pour en savoir plus<span class="wb-invisible"> - La Strat&eacute;gie nationale d''approvisionnement en mati&egrave;re de construction navale</span></a></p>\r\n  -->\r\n		</div>\r\n		<div class="span-5 row-start margin-bottom-none float-left"><img src="images/splashfpcc.jpg" alt="Publications du gouvernement du Canada" width="600" height="250" />\r\n		</div>\r\n		<div class="clear">&nbsp;</div>\r\n	</div>\r\n	<!-- TAB END -->\r\n	<!-- TAB START -->\r\n	<div id="tab02">\r\n		<h3 class="align-left span-3 position-right margin-top-none margin-bottom-none">SÉANCE PUBLIQUE</h3>\r\n		<div class="span-3 row-end margin-bottom-none float-right">\r\n			<p class="margin-right-medium margin-top-xlarge-custom">Raspberry Industry Development Council de la Colombie-Britannique. Dans le cadre d''une enquête sur le bien-fondé de la création d''un office de recherche, de développement des marchés et de promotion pour la framboise rouge. La prochaine séance publique aura lieu le 5 novembre 2013 à Ottawa, Ontario.</p>\r\n			<!-- <p class="margin-right-medium margin-top-large"><a href="http://publications.gc.ca/site/fra/accueil.html" class="button button-accent">\r\n  Pour en savoir plus<span class="wb-invisible"> - Publications du gouvernement du Canada</span></a></p>\r\n  -->\r\n		</div>\r\n		<div class="span-5 row-start margin-bottom-none float-left"><a href="/index.php/fr-FR/pageaccueil/actualites/1365-seance-publique-5-nov-2013"><img src="images/ebauchecpac.jpg" alt="Publications du gouvernement du Canada" width="600" height="250" /></a>\r\n		</div>\r\n		<div class="clear">&nbsp;</div>\r\n	</div>\r\n	<!-- TAB END -->\r\n</div>\r\n<ul class="tabs">\r\n	<li><a href="#tab01">1<span class="wb-invisible">: Le CPAC lance son nouveau site Web</span></a></li>\r\n	<li><a href="#tab02">2<span class="wb-invisible">: SÉANCE PUBLIQUE</span></a></li>\r\n</ul>', 1, 'extra1', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(10097, 'Langues Switcher', '', '', 0, 'top3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_languages', 1, 0, '{"header_text":"","footer_text":"","dropdown":"0","image":"0","inline":"1","show_active":"1","full_name":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(10095, 'Wet-Slider - Anglais', '', '<div class="tabs-panel">\r\n	<!-- TAB START -->\r\n	<div id="tab01">\r\n		<h3 class="align-left span-3 position-right margin-top-none margin-bottom-none">FPCC launch its new Web site!</h3>\r\n		<div class="span-3 row-end margin-bottom-none float-right">\r\n			<p class="margin-right-medium margin-top-xlarge-custom">The sittings are now closed. The Panel heard from multiple presenters during the hearings. As for next steps, the Panel will evaluate all material submitted and presented and make its report and recommendations to the Council which will then make recommendations to the Minister of Agriculture and Agri-Food.</p>\r\n			<!-- <p class="margin-right-medium margin-top-large">\r\n  <a href="http://nouvelles.gc.ca/web/article-fr.do?mthd=tp&amp;crtr.page=1&amp;nid=814209&amp;crtr.tp1D=1" class="button button-accent">Pour en savoir plus<span class="wb-invisible"> - La Strat&eacute;gie nationale d''approvisionnement en mati&egrave;re de construction navale</span></a></p>\r\n  -->\r\n		</div>\r\n		<div class="span-5 row-start margin-bottom-none float-left"><img src="images/splashfpcc.jpg" alt="Publications du gouvernement du Canada" width="600" height="250" />\r\n		</div>\r\n		<div class="clear">&nbsp;</div>\r\n	</div>\r\n	<!-- TAB END -->\r\n	<!-- TAB START -->\r\n	<div id="tab02">\r\n		<h3 class="align-left span-3 position-right margin-top-none margin-bottom-none">Pullet Growers of Canada</h3>\r\n		<div class="span-3 row-end margin-bottom-none float-right">\r\n			<p class="margin-right-medium margin-top-xlarge-custom">The sittings are now closed. The Panel heard from multiple presenters during the hearings. As for next steps, the Panel will evaluate all material submitted and presented and make its report and recommendations to the Council which will then make recommendations to the Minister of Agriculture and Agri-Food.</p>\r\n			<!-- <p class="margin-right-medium margin-top-large"><a href="http://publications.gc.ca/site/fra/accueil.html" class="button button-accent">\r\n  Pour en savoir plus<span class="wb-invisible"> - Publications du gouvernement du Canada</span></a></p>\r\n  -->\r\n		</div>\r\n		<div class="span-5 row-start margin-bottom-none float-left"><a href="/index.php/eb-GB/pageaccueil/actualites/1365-seance-publique-5-nov-2013"><img src="images/ebauchecpac.jpg" alt="Publications du gouvernement du Canada" width="600" height="250" /></a>\r\n		</div>\r\n		<div class="clear">&nbsp;</div>\r\n	</div>\r\n	<!-- TAB END -->\r\n</div>\r\n<ul class="tabs">\r\n	<li><a href="#tab01">1<span class="wb-invisible">: FPCC launch its new Web site</span></a></li>\r\n	<li><a href="#tab02">2<span class="wb-invisible">: Pullet Growers of Canada</span></a></li>\r\n</ul>', 1, 'extra1', 342, '2014-02-11 19:59:06', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(10089, 'Search', '', '', 1, 'extra2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_search', 1, 0, '{"label":"","width":"40","text":"","button":"1","button_pos":"right","imagebutton":"","button_text":"Search","opensearch":"1","opensearch_title":"","set_itemid":"","layout":"_:default","moduleclass_sfx":"-cpac-textblock","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB'),
(10079, 'FAST LINKS', '', '', 1, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 0, '{"menutype":"menurapidefrancais","startLevel":"1","endLevel":"2","showAllChildren":"1","tag_id":"","class_sfx":"cpac-vmenu","window_open":"","layout":"_:default","moduleclass_sfx":"cpac-vmenu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB'),
(10080, 'INTRANET', '', '', 1, 'left', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"intranetfrancais","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"cpac-vmenu","layout":"_:default","moduleclass_sfx":"cpac-vmenu","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB'),
(10082, 'Menu principal anglais', '', '', 6, 'user3', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_menu', 1, 0, '{"menutype":"topmenufrancais","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB'),
(10087, 'Josetta jump', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_josetta_jump', 1, 1, '', 1, '*'),
(10088, 'Josetta translations', 'Provides a quick access to Josetta front-end translation manager.', '', 0, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_josetta_jump', 4, 1, '{"0":""}', 1, '*'),
(10092, 'Bar de recherche', '', '<div id="gcwu-srchbx">\r\n	<h2>Recherche</h2>\r\n	<form action="/index.php/fr-FR/publications/lignes-directrices" method="post">\r\n		<div id="gcwu-srchbx-in"><input type="hidden" name="option" value="com_search" /><input type="hidden" name="Itemid" value="296" /><label for="gcwu-srch">Recherchez le site Web</label><input id="gcwu-srch" type="search" name="searchword" value="" size="27" maxlength="150" /><input id="gcwu-srch-submit" type="submit" name="gcwu-srch-submit" value="Recherche" data-icon="search" />\r\n		</div>\r\n	</form>\r\n</div>', 1, 'extra2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*');
INSERT INTO `vwqtd_modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(10093, 'Bar de recherche - Anglais', '', '<div id="gcwu-srchbx">\r\n<h2>Search</h2>\r\n<form action="/index.php/en-GB/component/search" method="post">\r\n<div id="gcwu-srchbx-in"><input type="hidden" name="option" value="com_search" /> <input type="hidden" name="Itemid" value="296" /> <label for="gcwu-srch">Search the website</label> <input id="gcwu-srch" type="search" name="searchword" value="" size="27" maxlength="150" /> <input id="gcwu-srch-submit" type="submit" name="gcwu-srch-submit" value="Search" data-icon="search" /></div>\r\n</form></div>\r\n<p>&nbsp;</p>', 0, 'extra2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(10096, 'Fil - Anglais', '', '', 1, 'breadcrumb', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 0, '{"showHere":"0","showHome":"1","homeText":"Home","showLast":"1","separator":">","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, 'en-GB');

-- --------------------------------------------------------

--
-- Table structure for table `vwqtd_modules_menu`
--

CREATE TABLE IF NOT EXISTS `vwqtd_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vwqtd_modules_menu`
--

INSERT INTO `vwqtd_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(79, 0),
(86, 0),
(10027, 113),
(10027, 127),
(10027, 128),
(10027, 129),
(10027, 160),
(10027, 161),
(10027, 163),
(10027, 165),
(10027, 166),
(10027, 168),
(10027, 169),
(10027, 171),
(10027, 172),
(10027, 208),
(10027, 209),
(10027, 211),
(10027, 212),
(10027, 216),
(10027, 217),
(10027, 218),
(10027, 219),
(10027, 237),
(10027, 238),
(10027, 239),
(10027, 244),
(10027, 245),
(10027, 246),
(10027, 247),
(10027, 249),
(10027, 250),
(10027, 251),
(10027, 255),
(10027, 256),
(10027, 288),
(10027, 289),
(10027, 290),
(10027, 291),
(10027, 292),
(10027, 293),
(10027, 294),
(10027, 295),
(10027, 296),
(10027, 297),
(10027, 298),
(10027, 299),
(10027, 560),
(10027, 576),
(10027, 577),
(10037, 127),
(10045, 0),
(10046, 0),
(10048, 0),
(10050, 127),
(10060, 0),
(10061, 0),
(10062, 0),
(10064, 0),
(10065, 0),
(10066, 0),
(10067, 127),
(10068, 0),
(10069, 0),
(10070, 0),
(10072, 0),
(10073, 0),
(10074, 0),
(10075, 0),
(10076, 127),
(10076, 308),
(10077, 308),
(10078, 0),
(10079, 0),
(10080, 0),
(10081, 308),
(10081, 523),
(10082, 0),
(10086, 0),
(10088, 0),
(10089, 0),
(10090, 0),
(10091, 0),
(10092, 0),
(10093, 0),
(10094, 127),
(10095, 308),
(10096, 308),
(10096, 310),
(10096, 311),
(10096, 312),
(10096, 525),
(10096, 526),
(10096, 527),
(10096, 528),
(10096, 529),
(10096, 530),
(10096, 531),
(10096, 532),
(10096, 533),
(10096, 534),
(10096, 535),
(10096, 536),
(10096, 537),
(10096, 538),
(10096, 539),
(10096, 540),
(10096, 541),
(10096, 542),
(10096, 543),
(10096, 544),
(10096, 545),
(10096, 546),
(10096, 547),
(10096, 548),
(10096, 549),
(10096, 550),
(10096, 551),
(10096, 552),
(10096, 553),
(10096, 554),
(10096, 555),
(10096, 556),
(10096, 557),
(10096, 560),
(10096, 562),
(10096, 563),
(10096, 564),
(10096, 565),
(10096, 566),
(10096, 567),
(10096, 578),
(10097, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
